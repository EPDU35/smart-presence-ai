/**
 * unknown-device-alert.ts
 * Alerte l'admin et l'utilisateur quand un nouvel appareil est détecté.
 */

import { supabase } from "@/lib/supabase";
import { getFullDeviceFingerprint } from "./fingerprint-generation";
import { getDeviceName } from "@/utils/device";

export interface NewDeviceAlertPayload {
  userId: string;
  companyId: string;
  deviceName: string;
  deviceFingerprint: string;
  detectedAt: string;
}

/**
 * Crée une alerte dans suspicious_logs pour le nouvel appareil.
 * L'admin verra ça dans son dashboard (unresolved suspicious events).
 */
export async function alertNewDevice(
  userId: string,
  companyId: string
): Promise<void> {
  const deviceName = getDeviceName();
  const fingerprint = getFullDeviceFingerprint();

  const payload: NewDeviceAlertPayload = {
    userId,
    companyId,
    deviceName,
    deviceFingerprint: fingerprint,
    detectedAt: new Date().toISOString(),
  };

  await supabase.from("suspicious_logs").insert({
    user_id: userId,
    company_id: companyId,
    reason: "NEW_DEVICE_DETECTED",
    device: fingerprint,
    metadata: payload,
    resolved: false,
  });
}

/**
 * Vérifie si un device est nouveau pour cet utilisateur.
 * Retourne true si aucun device avec cette empreinte n'existe en base.
 */
export async function isNewDevice(userId: string): Promise<boolean> {
  const fingerprint = getFullDeviceFingerprint();

  const { count } = await supabase
    .from("devices")
    .select("*", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("device_fingerprint", fingerprint);

  return (count ?? 0) === 0;
}

/**
 * Flow complet : si nouveau device → alerte + enregistrement.
 * À appeler après le login réussi.
 */
export async function handleDeviceCheckOnLogin(
  userId: string,
  companyId: string | null
): Promise<{ isNew: boolean }> {
  const newDevice = await isNewDevice(userId);

  if (newDevice && companyId) {
    // Alerte async — ne bloque pas le login
    alertNewDevice(userId, companyId).catch(console.error);
  }

  return { isNew: newDevice };
}